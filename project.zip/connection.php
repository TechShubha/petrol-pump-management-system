<?php
$con=new mysqli('localhost','root','','project');
if(!$con){
    die(mysqli_error($con));
}
?>